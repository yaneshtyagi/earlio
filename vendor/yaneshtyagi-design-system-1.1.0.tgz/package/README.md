# @yaneshtyagi/design-system

BrainVault Design System v1.1: React components, design tokens and CSS shared by every BrainVault product. It follows `docs/BrainVault-Design-System.pdf`.

## Install

The package is published to GitHub Packages and is private. Point the `@yaneshtyagi` scope at it in the `.npmrc` of the project that uses it:

```ini
@yaneshtyagi:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

`NODE_AUTH_TOKEN` is a GitHub personal access token (classic) with the `read:packages` scope, owned by someone with access to this repository. Never commit the token. In GitHub Actions of another repository, use a token that can read this one (the default `GITHUB_TOKEN` cannot read packages from a different repository unless that repository is granted access under the package's settings).

```sh
npm install @yaneshtyagi/design-system
```

Peer dependencies: `react` and `react-dom` 18 or 19.

## Set up

```tsx
// main.tsx
import "@yaneshtyagi/design-system/fonts.css";   // Geist, Sora, JetBrains Mono (Google Fonts)
import "@yaneshtyagi/design-system/styles.css";  // tokens + all component CSS

import { ThemeProvider, AppRoot, ToastProvider } from "@yaneshtyagi/design-system";

root.render(
  <ThemeProvider>            {/* light/dark via data-theme on <html>; light is the fallback */}
    <ToastProvider>
      <AppRoot>
        <App />
      </AppRoot>
    </ToastProvider>
  </ThemeProvider>,
);
```

Load `tokens.css` and `components/bundle.css` separately if you prefer.

## Components

- Actions and forms: `Button`, `LinkButton`, `TextField`, `SelectField`, `TextareaField`, `MoneyField`, `SearchInput`, `Checkbox`, `RadioGroup`, `Switch`, form layout and error summary
- Status and feedback: `Badge`, `StatusBadge`, `Tag`, `Count`, `Progress`, `Stepper`, `Timeline`, `Avatar`, `Alert`, `Toast`, `EmptyState`, `Skeleton`
- Hierarchy and records: `TreeView`, `Accordion`, `DescriptionList`
- Inputs: `Combobox` (searchable select), `FileUpload`
- Identity and markers: `AppIdentity` (title, subtitle, version), `McpBadge`, the `ai` and `mcp` glyphs
- Dates and times: `DatePicker`, `TimePicker`, `DateTimePicker`, `DateRangePicker`, `TimeRangePicker`, `Calendar` (see below)
- Data: `Money`, `Card`, `Stat`, `KpiRow`, `DataTable`, `Pagination`, `FilterChip`, `ChartCard`, `BarList`, `BarChart`
- Navigation and overlays: `AppShell`, `Sidebar`, `Topbar`, `PageHeader`, `Breadcrumb`, `Tabs`, `Segmented`, `Menu`, `Tooltip`, `Modal`, `ConfirmDialog`, `Drawer`
- Domain: `MaskedIdentifier`, `AiSuggestion`, maker-checker state (fintech); `CourseProgress`, `AttendanceCode` (edtech)
- Utilities: `formatMoney` (INR lakh grouping), `formatDate`, `formatDateRange`, `formatPercent`, `formatDelta`, `formatGrade`, `formatAttendance`, `maskIdentifier`, `Icon` (Lucide starter set)

Content rules from the spec (sentence case, real minus sign, `22 Oct 2026` dates, tabular figures) are built into the components and formatters.

## Dates and times

One set of controls for every product, so teams stop building their own. They all share one calendar, one date-math module and one set of rules.

| Control | Use it for | Value |
| --- | --- | --- |
| `DatePicker` | A single date field | `"2026-10-22"` or `null` |
| `TimePicker` | A 24-hour time field | `"15:30"` or `null` |
| `DateTimePicker` | A date and a time in one field | `"2026-10-22T15:30"` or `null` |
| `DateRangePicker` | A period, with optional presets | `{ start, end }` of dates |
| `TimeRangePicker` | Opening hours, session slots | `{ start, end }` of times |
| `Calendar` | An inline month view (timetables, due dates); `mode="range"` for ranges | a date or a date range |

```tsx
import { DatePicker, DateRangePicker, TimePicker, dateRangePresets } from "@yaneshtyagi/design-system";

<DatePicker label="Due date" value={due} onChange={setDue} min="2026-10-01" />
<DatePicker label="Date of birth" captionLayout="dropdown" max={today} required />
<TimePicker label="Session start" zoneLabel="IST" step={15} />
<DateRangePicker label="Statement period" presets={dateRangePresets()} value={period} onChange={setPeriod} />
```

**Values are plain strings, not `Date` objects.** A date is `"YYYY-MM-DD"`, a time is `"HH:mm"` (24-hour), a date-time is `"YYYY-MM-DDTHH:mm"` in local wall-clock time. They survive JSON and forms, and they cannot shift by a day across time zones. Convert to UTC with the user's zone at the API boundary, and pass `zoneLabel="IST"` when the zone matters.

**Typing works as well as picking.** Dates are read day first: `22 Oct 2026`, `22/10/2026`, `22-10-2026`, `2026-10-22`. Times read `15:30`, `1530`, `9`. A valid entry is rewritten in the house format (`22 Oct 2026`, `09:30`). Anything else keeps the typed text and shows a sentence that says what to do. `onChange` only ever receives a clean value or `null`.

**Limits and availability.** `min`, `max` and `isDateDisabled` apply to the calendar and to typed dates. `DateTimePicker` takes `min`/`max` as date-times and applies the time limit on the boundary day only. Use `markers` on `Calendar` for due dates and sessions (the label is read by screen readers; a conflict uses `tone: "danger"`).

**In forms.** Pass `name` and the control submits the ISO value in a hidden input. Pickers open above modals and drawers, and Esc closes the picker without closing the dialog beneath.

**Keyboard.** In the calendar: arrows move by day and week, Home and End to the week edges, PageUp and PageDown by month, Shift with those by year, Enter or Space to select. In a time list: arrows, Home, End, Enter. Alt+ArrowDown opens a picker from its input.

The helpers behind them are exported too: `formatISODate`, `formatISORange`, `parseDateInput`, `parseTimeInput`, `addDays`, `addMonths`, `todayISO` and more.

## Tree view, identity, AI and MCP

```tsx
<TreeView aria-label="Course outline" nodes={nodes} selected={id} onSelect={(id) => go(id)} icons="folders" />
<Sidebar productName="Earlio" subtitle="Developed by BrainVault" version="1.0" groups={groups} />
<AppIdentity name="Earlio" subtitle="Developed by BrainVault" version="1.0" layout="stacked" size="lg" as="h1" />
<Button icon="ai">Ask AI</Button>
<McpBadge />            {/* "MCP" chip: this feature is also available through MCP */}
<McpBadge iconOnly />   {/* for table headers and menu rows */}
```

- **`TreeView`** follows the WAI-ARIA tree pattern: one tab stop; Up and Down move; Right opens a branch or enters it; Left closes it or goes to the parent; Home and End jump; `*` opens every branch at that level; typing a letter jumps to the next label. Give a node an `href` (and your router's `linkComponent`) for navigation trees. Clicking a branch row selects and toggles it; the chevron only toggles.
- **`AppIdentity`** states who a product is the same way everywhere: title (Sora), subtitle, and a `v1.0` version chip. The `Sidebar` shows it when you pass `subtitle` or `version`; use it on sign-in (`layout="stacked"`, `as="h1"`), in About dialogs and in footers. The logo file, when bundled, goes in `logo`.
- **`ai` glyph** (Lucide sparkles): invoke or mark the built-in AI. Always pair it with a word ("Ask AI", "AI suggestion"). Content the AI produced uses the `discovery` tone and the `AiSuggestion` pattern.
- **`mcp` glyph** (an original BrainVault drawing, since Lucide has none): marks a feature or operation that is also available through MCP. Use `McpBadge` rather than the bare glyph, so it always carries a text name.
- Other new glyphs: `folder`, `folder-open`, `external-link`, `history` (audit trail). The 54-glyph starter set is unchanged.

## Disclosure, record details and inputs

- **`Accordion`**: sections that open in place (`type="single"` or `"multiple"`). Closed sections stay in the page, so fields inside keep their values.
- **`DescriptionList`**: label and value pairs for a record page; missing values show a dash and say "Not provided".
- **`Combobox`**: a select you can search. Pick from the list only; for server-side search pass `filter={null}`, `loading` and `onQueryChange`. For a short list use `SelectField`.
- **`FileUpload`**: choose or drop files, with type, size and count checked up front and a sentence for each rejection. It picks and checks files; your app sends them and reports progress through `status`.

## Develop

```sh
npm install
npm run dev        # playground: app shell at /, all components at /gallery.html
npm run check      # typecheck + tests (tokens, contrast, behaviour) + build
```

## Publish

1. Bump `version` in `package.json`.
2. `npm run check` (also runs on `prepublishOnly`).
3. Commit, then push a tag that matches the version, for example `git tag v1.1.0 && git push origin v1.1.0`. `.github/workflows/publish.yml` runs the checks and publishes to GitHub Packages with the built-in `GITHUB_TOKEN`; no secret needs to be added. The workflow fails if the tag and `package.json` version differ.

A version can be published only once; to fix a bad release, bump the version.
